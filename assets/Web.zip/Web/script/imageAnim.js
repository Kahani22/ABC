(() => {
	// set up the puzzle pieces and boards
	
})();
